import React, { Component } from 'react';

class Cart extends Component {
  render() {
    return (
      <div>
      Cart
      </div>
    );
  }
}

export default Cart;