import React from 'react';

const NotFound = () => {
        return (
            <p>Not Found</p>
        );
}

export default NotFound;
